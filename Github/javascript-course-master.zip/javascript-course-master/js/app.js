// console.log("hello world!");
// Biến - Variables
// camelCase -> evondev -> evonDev
// i love my school -> iLoveMySchool
// Không nên đặt tiếng Việt, hoặc có dấu, hoặc các kí tự đặc biệt, các từ hệ thống, tentoi, toila, canhgiua,
// Delcare variable: Khai báo biến
// const and let
const number = 100;
console.log(number);
// number = 200;
let otherNumber = 200;
otherNumber = "Welcome to my Javascript course";
console.log(otherNumber);
// Hoisting
const anotherNumber = true; //Boolean
let otherValue = undefined; // Undefined null
console.log(anotherNumber);
// Data Types: Number, String, Boolean, Undefined, Null
// const và let ko bị hoisting
// var sẽ bị hoisting
// khi mà khai báo biến mà chưa gán giá trị gì cả ví dụ var a;
// var a; // undefined
// console.log(a);
// console.log(a);
// var a;
var a;
console.log(a);

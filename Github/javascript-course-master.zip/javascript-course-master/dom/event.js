// 1. Sự kiện là gì ? (event)
// 2. Thêm 1 sự kiện: selector.addEventListener("eventName", handler, [options])
// click, keydown, keypress, keyup, mouseover, mousemove, mouseleave, load, DOMContentLoaded,...
// handler: function
// capture, bubbling
// 3. Sự kiện click
